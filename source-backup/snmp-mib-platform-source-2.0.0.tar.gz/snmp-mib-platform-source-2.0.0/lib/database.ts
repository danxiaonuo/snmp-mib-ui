/**
 * MIB 监控平台数据库操作库
 * 使用SQLite提供轻量级数据库支持
 */

// 导入SQLite数据库实现
export * from './database-sqlite';