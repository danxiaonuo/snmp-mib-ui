/**
 * 缓存系统
 * 使用内存缓存替代Redis
 */

// 导入内存缓存实现
export * from './memory-cache';
