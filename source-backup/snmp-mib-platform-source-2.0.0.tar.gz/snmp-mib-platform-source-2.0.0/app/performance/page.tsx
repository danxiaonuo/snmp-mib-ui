import { PerformanceAnalysis } from "@/components/enhanced/enhanced-frontend-components"

export default function PerformancePage() {
  return <PerformanceAnalysis />
}
