export default function SimplePage() {
  return <h1>Simple Test Page Works!</h1>
}