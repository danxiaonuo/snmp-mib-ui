import { SecurityCompliance } from "@/components/enhanced/enhanced-frontend-components"

export default function CompliancePage() {
  return <SecurityCompliance />
}
