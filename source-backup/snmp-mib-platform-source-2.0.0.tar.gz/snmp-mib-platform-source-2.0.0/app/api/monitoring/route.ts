import { handleMonitoringAPI } from "@/app/api/enhanced/api-integration-routes"
export { handleMonitoringAPI as GET, handleMonitoringAPI as POST, handleMonitoringAPI as PUT, handleMonitoringAPI as DELETE }
