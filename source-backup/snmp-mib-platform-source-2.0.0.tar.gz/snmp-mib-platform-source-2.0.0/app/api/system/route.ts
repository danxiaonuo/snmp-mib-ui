import { handleSystemAPI } from "@/app/api/enhanced/api-integration-routes"
export { handleSystemAPI as GET, handleSystemAPI as POST, handleSystemAPI as PUT, handleSystemAPI as DELETE }
