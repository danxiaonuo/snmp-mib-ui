import { handlePerformanceAPI } from "@/app/api/enhanced/api-integration-routes"
export { handlePerformanceAPI as GET, handlePerformanceAPI as POST, handlePerformanceAPI as PUT, handlePerformanceAPI as DELETE }
