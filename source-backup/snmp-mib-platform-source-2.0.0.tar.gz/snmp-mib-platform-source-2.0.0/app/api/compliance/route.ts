import { handleComplianceAPI } from "@/app/api/enhanced/api-integration-routes"
export { handleComplianceAPI as GET, handleComplianceAPI as POST, handleComplianceAPI as PUT, handleComplianceAPI as DELETE }
