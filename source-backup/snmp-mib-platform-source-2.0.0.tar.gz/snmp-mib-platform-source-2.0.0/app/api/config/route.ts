import { handleConfigAPI } from "@/app/api/enhanced/api-integration-routes"
export { handleConfigAPI as GET, handleConfigAPI as POST, handleConfigAPI as PUT, handleConfigAPI as DELETE }
