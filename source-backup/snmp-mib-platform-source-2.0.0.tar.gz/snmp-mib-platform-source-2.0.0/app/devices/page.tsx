import { DeviceManagement } from "@/components/enhanced/enhanced-frontend-components"

export default function DevicesPage() {
  return <DeviceManagement />
}
