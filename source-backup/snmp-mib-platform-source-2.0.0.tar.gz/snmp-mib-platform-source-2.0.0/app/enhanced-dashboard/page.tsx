import APIIntegratedDashboardPage from './api-integrated-page'

export default function EnhancedDashboardPage() {
  return <APIIntegratedDashboardPage />
}