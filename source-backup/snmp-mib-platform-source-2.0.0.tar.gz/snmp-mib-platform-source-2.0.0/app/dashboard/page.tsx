import { EnhancedDashboard } from "@/components/enhanced/enhanced-frontend-components"

export default function DashboardPage() {
  return <EnhancedDashboard />
}
