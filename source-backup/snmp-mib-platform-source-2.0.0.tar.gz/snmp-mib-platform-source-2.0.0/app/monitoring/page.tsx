import { RealTimeMonitoring } from "@/components/enhanced/enhanced-frontend-components"

export default function MonitoringPage() {
  return <RealTimeMonitoring />
}
